package edu.spcollege.titanbank.bll;

public class InvalidPasswordException extends Exception {

    public InvalidPasswordException() {
        super("Invalid Password.");
    }
    
}
